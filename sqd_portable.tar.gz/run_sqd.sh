#!/bin/bash
# SQD 醋酸脚本 —— 一键部署+运行
# 用法：在目标机器上执行 bash run_sqd.sh
# 会自动创建虚拟环境、装依赖、跑代码

set -e

echo "============================================"
echo "SQD 醋酸脚本部署"
echo "============================================"

# 1. 检测 Python
if ! command -v python3 &> /dev/null; then
    echo "错误：需要 Python 3.10+，请先安装"
    exit 1
fi
echo "Python: $(python3 --version)"

# 2. 创建虚拟环境
echo ""
echo "=== 创建虚拟环境 ==="
python3 -m venv sqd-env
source sqd-env/bin/activate
pip install --upgrade pip

# 3. 安装依赖
echo ""
echo "=== 安装依赖（约 2-3 分钟）==="
pip install \
    numpy==2.5.1 \
    pyscf==2.14.0 \
    qiskit==2.5.1 \
    qiskit-addon-sqd==0.12.1 \
    ffsim==0.0.83 \
    scipy==1.18.0

# 4. 验证
echo ""
echo "=== 验证安装 ==="
python3 -c "
import pyscf, qiskit, ffsim, numpy, scipy
print(f'numpy {numpy.__version__}')
print(f'pyscf {pyscf.__version__}')
print(f'qiskit {qiskit.__version__}')
print(f'ffsim OK')
print(f'scipy {scipy.__version__}')
print('全部安装成功！')
"

# 5. 运行
echo ""
echo "=== 运行 SQD（约 5 分钟）==="
echo "开始: $(date)"
python3 sqd_acetic_acid.py 2>&1 | tee sqd_output.log
echo "结束: $(date)"

echo ""
echo "============================================"
echo "完成！输出保存在 sqd_output.log"
echo "============================================"
